<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ProductAdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware(function ($request, $next) {
            if (auth()->user()->role !== 'admin') abort(403);
            return $next($request);
        });
    }

    /**
     * Daftar semua produk + search
     */
    public function index(Request $request)
    {
        $query = Product::with(['category']);

        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        $products   = $query->latest()->paginate(12)->withQueryString();
        $categories = Category::orderBy('name')->get();

        return view('admin.products', compact('products', 'categories'));
    }

    /**
     * Simpan produk baru
     */
    public function store(Request $request)
    {
        $request->validate([
            'name'        => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'price'       => 'required|numeric|min:0',
            'stock'       => 'required|integer|min:0',
            'description' => 'required|string',
            'image'       => 'nullable|image|mimes:jpeg,png,jpg,webp|max:3072',
        ]);

        $slug = Str::slug($request->name);
        // Pastikan slug unik
        $originalSlug = $slug;
        $i = 1;
        while (Product::where('slug', $slug)->exists()) {
            $slug = $originalSlug . '-' . $i++;
        }

        $imagePath = null;
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('products', 'public');
        }

        $product = Product::create([
            'category_id' => $request->category_id,
            'name'        => $request->name,
            'slug'        => $slug,
            'description' => $request->description,
            'price'       => $request->price,
            'stock'       => $request->stock,
            'image'       => $imagePath,
            'spec_title'  => $request->spec_title,
            'spec_description' => $request->spec_description,
        ]);

        // Handle highlights as JSON
        if ($request->has('highlights')) {
            $highlights = [];
            foreach ($request->highlights as $hl) {
                if (!empty($hl['label']) || !empty($hl['title'])) {
                    $highlights[] = [
                        'label' => $hl['label'] ?? '',
                        'title' => $hl['title'] ?? '',
                        'description' => $hl['description'] ?? ''
                    ];
                }
            }
            $product->highlights = $highlights;
        }

        // Handle variations as JSON
        $variations = [];
        if ($request->has('capacities')) {
            foreach ($request->capacities as $cap) {
                if (!empty($cap['value']) && isset($cap['price'])) {
                    $variations[] = [
                        'type' => 'capacity',
                        'value' => $cap['value'],
                        'price' => (int) $cap['price']
                    ];
                }
            }
        }

        if ($request->has('colors')) {
            foreach ($request->colors as $col) {
                if (!empty($col['value'])) {
                    $variations[] = [
                        'type' => 'color',
                        'value' => $col['value'],
                        'price' => null
                    ];
                }
            }
        }

        $product->variations = !empty($variations) ? $variations : null;
        $product->save();

        return redirect()->route('admin.products')->with('success', 'Produk "' . $request->name . '" berhasil ditambahkan!');
    }

    /**
     * Update produk
     */
    public function update(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        $request->validate([
            'name'        => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'price'       => 'required|numeric|min:0',
            'stock'       => 'required|integer|min:0',
            'description' => 'required|string',
            'image'       => 'nullable|image|mimes:jpeg,png,jpg,webp|max:3072',
        ]);

        // Update slug if name changed
        $slug = $product->slug;
        if ($product->name !== $request->name) {
            $slug = Str::slug($request->name);
            $originalSlug = $slug;
            $i = 1;
            while (Product::where('slug', $slug)->where('id', '!=', $id)->exists()) {
                $slug = $originalSlug . '-' . $i++;
            }
        }

        $imagePath = $product->image;
        if ($request->hasFile('image')) {
            // Hapus gambar lama
            if ($product->image) {
                \Storage::disk('public')->delete($product->image);
            }
            $imagePath = $request->file('image')->store('products', 'public');
        }

        $product->update([
            'category_id' => $request->category_id,
            'name'        => $request->name,
            'slug'        => $slug,
            'description' => $request->description,
            'price'       => $request->price,
            'stock'       => $request->stock,
            'image'       => $imagePath,
            'spec_title'  => $request->spec_title,
            'spec_description' => $request->spec_description,
        ]);

        // Handle highlights as JSON
        if ($request->has('highlights')) {
            $highlights = [];
            foreach ($request->highlights as $hl) {
                if (!empty($hl['label']) || !empty($hl['title'])) {
                    $highlights[] = [
                        'label' => $hl['label'] ?? '',
                        'title' => $hl['title'] ?? '',
                        'description' => $hl['description'] ?? ''
                    ];
                }
            }
            $product->highlights = $highlights;
        } else {
            $product->highlights = null;
        }

        // Handle variations as JSON
        $variations = [];
        if ($request->has('capacities')) {
            foreach ($request->capacities as $cap) {
                if (!empty($cap['value']) && isset($cap['price'])) {
                    $variations[] = [
                        'type' => 'capacity',
                        'value' => $cap['value'],
                        'price' => (int) $cap['price']
                    ];
                }
            }
        }

        if ($request->has('colors')) {
            foreach ($request->colors as $col) {
                if (!empty($col['value'])) {
                    $variations[] = [
                        'type' => 'color',
                        'value' => $col['value'],
                        'price' => null
                    ];
                }
            }
        }

        $product->variations = !empty($variations) ? $variations : null;
        $product->save();

        return redirect()->route('admin.products')->with('success', 'Produk berhasil diperbarui!');
    }

    /**
     * Hapus produk
     */
    public function destroy($id)
    {
        $product = Product::findOrFail($id);

        if ($product->image) {
            \Storage::disk('public')->delete($product->image);
        }

        $product->delete();

        return redirect()->route('admin.products')->with('success', 'Produk berhasil dihapus.');
    }

    // ─────────────────────────────────────────────
    //  CATEGORY MANAGEMENT METHODS
    // ─────────────────────────────────────────────

    /**
     * Get all categories (for AJAX)
     */
    public function categoriesIndex()
    {
        $categories = Category::orderBy('name')->get();
        return response()->json($categories);
    }

    /**
     * Store new category
     */
    public function storeCategory(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255|unique:categories,name'
        ]);

        $category = Category::create([
            'name' => $request->name,
            'slug' => Str::slug($request->name)
        ]);

        return redirect()->route('admin.products')->with('success', 'Kategori "' . $category->name . '" berhasil ditambahkan!');
    }

    /**
     * Update category
     */
    public function updateCategory(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255|unique:categories,name,' . $id
        ]);

        $category = Category::findOrFail($id);
        $category->update([
            'name' => $request->name,
            'slug' => Str::slug($request->name)
        ]);

        return redirect()->route('admin.products')->with('success', 'Kategori berhasil diupdate!');
    }

    /**
     * Delete category
     */
    public function destroyCategory($id)
    {
        $category = Category::findOrFail($id);
        
        // Update products in this category to null
        Product::where('category_id', $id)->update(['category_id' => null]);
        
        $category->delete();

        return redirect()->route('admin.products')->with('success', 'Kategori berhasil dihapus!');
    }
}